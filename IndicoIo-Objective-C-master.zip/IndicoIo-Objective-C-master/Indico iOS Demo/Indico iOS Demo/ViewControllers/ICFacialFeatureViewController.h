//
//  ICFacialFeatureViewController.h
//  Indico iOS Demo
//
//  Created by Indico on 14/10/14.
//  Copyright (c) 2014 Indico. All rights reserved.
//

#import "ICImageBaseViewController.h"

@interface ICFacialFeatureViewController : ICImageBaseViewController

@end

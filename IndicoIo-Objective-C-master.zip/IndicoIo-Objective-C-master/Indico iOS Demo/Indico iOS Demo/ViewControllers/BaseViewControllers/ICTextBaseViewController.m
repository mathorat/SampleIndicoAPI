//
//  ICTextBaseViewController.m
//  Indico iOS Demo
//
//  Created by Indico on 14/10/14.
//  Copyright (c) 2014 Indico. All rights reserved.
//

#import "ICTextBaseViewController.h"

@interface ICTextBaseViewController ()

@end

@implementation ICTextBaseViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
}

@end

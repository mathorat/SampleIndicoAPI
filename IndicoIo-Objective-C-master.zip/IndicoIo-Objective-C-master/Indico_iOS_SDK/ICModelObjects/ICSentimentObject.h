//
//  ICSentimentObject.h
//
//  Created by Indico  on 15/10/14
//  Copyright (c) 2014 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ICBaseModelObject.h"

@interface ICSentimentObject : ICBaseModelObject

@property (nonatomic, assign) double results;

@end
